import java.awt.image.BufferedImage
import javax.imageio.ImageIO
import java.io.File
import java.awt.Color
import scala.annotation.tailrec

object BMPExample {
  def main(args: Array[String]): Unit = {
    // Rutas de entrada y salida
    val inputPath        = "squirtle_squad_BMP_00.bmp"
    val grayOutputPath   = "salida_bn.bmp"
    val pixelOutputPath  = "salida_pixelado.bmp"
    val colorOutputPath  = "salida_color.bmp"

    // Elegir el color a filtrar: "red", "green" o "blue"
    val chosenColor = "red"

    // Leer imagen original
    val original: BufferedImage = ImageIO.read(new File(inputPath))
    val width  = original.getWidth
    val height = original.getHeight

    // -------------------------------------------------------------------------
    // 1. Imagen en escala de grises
    // -------------------------------------------------------------------------
    val grayImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB)

    @tailrec
    def drawGray(x: Int, y: Int): Unit = {
      if (y < height) {
        if (x < width) {
          val color = new Color(original.getRGB(x, y))
          val grayValue = (0.299 * color.getRed + 0.587 * color.getGreen + 0.114 * color.getBlue).toInt
          val grayColor = new Color(grayValue, grayValue, grayValue)
          grayImage.setRGB(x, y, grayColor.getRGB)
          drawGray(x + 1, y)
        } else {
          drawGray(0, y + 1)
        }
      }
    }
    drawGray(0, 0)

    ImageIO.write(grayImage, "bmp", new File(grayOutputPath))

    // -------------------------------------------------------------------------
    // 2. Imagen pixelada
    // -------------------------------------------------------------------------
    val pixelImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB)
    val blockSize  = 10  // tamaño de cada bloque

    @tailrec
    def processBlocks(x: Int, y: Int): Unit = {
      if (y < height) {
        if (x < width) {
          val (sumR, sumG, sumB, count) = processBlockPixels(original, x, y, 0, 0, blockSize, width, height, 0, 0, 0, 0)
          val avgColor =
            if (count > 0) new Color(sumR / count, sumG / count, sumB / count)
            else new Color(255, 255, 255)

          fillBlock(pixelImage, x, y, 0, 0, blockSize, width, height, avgColor)
          processBlocks(x + blockSize, y)
        } else {
          processBlocks(0, y + blockSize)
        }
      }
    }
    processBlocks(0, 0)

    ImageIO.write(pixelImage, "bmp", new File(pixelOutputPath))

    // -------------------------------------------------------------------------
    // 3. Imagen filtrada por color (rojo, verde o azul)
    // -------------------------------------------------------------------------
    val colorImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB)

    @tailrec
    def filterColor(x: Int, y: Int): Unit = {
      if (y < height) {
        if (x < width) {
          val c = new Color(original.getRGB(x, y))
          val filtered = keepOrWhite(c, chosenColor)
          colorImage.setRGB(x, y, filtered.getRGB)
          filterColor(x + 1, y)
        } else {
          filterColor(0, y + 1)
        }
      }
    }
    filterColor(0, 0)

    ImageIO.write(colorImage, "bmp", new File(colorOutputPath))
  }

  // ===========================================================================
  //                      FUNCIONES AUXILIARES
  // ===========================================================================

  //
  // --- Pixelado: Sumar píxeles de un bloque
  //
  @tailrec
  def processBlockPixels(img: BufferedImage,
                         x0: Int, y0: Int,
                         dx: Int, dy: Int,
                         blockSize: Int,
                         width: Int, height: Int,
                         accR: Int, accG: Int, accB: Int, count: Int
                        ): (Int, Int, Int, Int) = {
    if (dy >= blockSize || (y0 + dy) >= height) {
      (accR, accG, accB, count)
    } else if (dx >= blockSize || (x0 + dx) >= width) {
      processBlockPixels(img, x0, y0, 0, dy + 1, blockSize, width, height, accR, accG, accB, count)
    } else {
      val c = new Color(img.getRGB(x0 + dx, y0 + dy))
      processBlockPixels(
        img, x0, y0,
        dx + 1, dy,
        blockSize, width, height,
        accR + c.getRed, accG + c.getGreen, accB + c.getBlue, count + 1
      )
    }
  }

  //
  // --- Pixelado: Rellenar un bloque con un color
  //
  @tailrec
  def fillBlock(pixelImage: BufferedImage,
                x0: Int, y0: Int,
                dx: Int, dy: Int,
                blockSize: Int,
                width: Int, height: Int,
                color: Color): Unit = {
    if (dy >= blockSize || (y0 + dy) >= height) {
      ()
    } else if (dx >= blockSize || (x0 + dx) >= width) {
      fillBlock(pixelImage, x0, y0, 0, dy + 1, blockSize, width, height, color)
    } else {
      pixelImage.setRGB(x0 + dx, y0 + dy, color.getRGB)
      fillBlock(pixelImage, x0, y0, dx + 1, dy, blockSize, width, height, color)
    }
  }

  //
  // --- Filtrado por color: Devuelve color original si cumple umbral, o blanco
  //     chosenColor: "red", "green", "blue"
  //
  def keepOrWhite(c: Color, chosenColor: String): Color = {
    val r = c.getRed
    val g = c.getGreen
    val b = c.getBlue

    chosenColor.toLowerCase match {
      case "red" =>
        // 100 <= R <= 255,  0 <= G < 150,  0 <= B < 150
        if (r >= 100 && r <= 255 && g >= 0 && g < 150 && b >= 0 && b < 150) c
        else Color.white

      case "green" =>
        // 30 <= R < 150,  50 <= G <= 255,  0 <= B < 75
        if (r >= 30 && r < 150 && g >= 50 && g <= 255 && b >= 0 && b < 75) c
        else Color.white

      case "blue" =>
        // 0 <= R < 200,  0 <= G < 250,  100 <= B <= 255
        if (r >= 0 && r < 200 && g >= 0 && g < 250 && b >= 100 && b <= 255) c
        else Color.white

      // En caso de que no sea ninguno de los anteriores, devolvemos el color original o blanco
      case _ =>
        c
    }
  }
}
